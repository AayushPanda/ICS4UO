package ICS;

import java.io.PrintStream;

public class Main {
    public static void main(String[] args) {
        // Entrypoint, no code here :)
    }
}